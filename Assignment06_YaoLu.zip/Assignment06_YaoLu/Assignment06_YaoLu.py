#-------------------------------------------------#
# Title: Functions and Classes
# Dev:   Yao Lu
# Date:  Feb 18, 2018
#-------------------------------------------------#

#-- Data -- #
objFileName = "C:\_PythonClass\Todo.txt"
strData = ""
dicRow = {}
lstTable = []

#-- Input --# 
class UserInput:
    @staticmethod
    def MenuOptionInput(): #choose an option
        strChoice = str(input("Which option would you like to perform? [1 to 5] - "))
        print()
        return strChoice

    @staticmethod
    def AddTaskInput():  #Option 2
        strTask = str(input("What is the task? - ")).strip()
        strPriority = str(input("What is the priority? [high|low] - ")).strip()
        return strTask, strPriority
    #end of AddTask function

    @staticmethod
    def RemoveTaskInput(): #Option 3
        strKeyToRemove = input("Which TASK would you like removed? - ")
        return strKeyToRemove
    #end of RemoveTask function

    @staticmethod
    def SaveDataInput(): #Option 4
        strSaveData = str(input("Save this data to file? (y/n) - ")).strip().lower()
        return strSaveData
    # end of SaveData function


#end of input


#-- Output --#
class output:
    @staticmethod
    def MenuOptions():
        print ("""
        Menu of Options
        1) Show current data
        2) Add a new item.
        3) Remove an existing item.
        4) Save Data to File
        5) Exit Program
        """)
    #end function

    @staticmethod
    def CurrentTasksOutput(TableofData): #show current items
        print("******* The current items ToDo are: *******")
        for row in lstTable:
            print(row["Task"] + "(" + row["Priority"] + ")")
        print("*******************************************")
        print()
    #end of CurrentTasks function

    @staticmethod
    def RemoveTaskOutput(ItemRemoved):#
        if (blnItemRemoved == True):
            print("The task was removed")
        else:
            print("I'm sorry, but I could not find that task.")
        print()
    #end of OutputRemoveTask

    @staticmethod
    def DataSaved():
        print((input("Data saved to file! Press the [Enter] key to return to menu.")))

    @staticmethod
    def DataNotSaved():
        print(input(
                "New data was NOT Saved, but previous data still exists! Press the [Enter] key to return to menu."))
# end of output


#-- Data Processing --#
class DataProcessing:
    @staticmethod
    def LoadData (FileName, TableofData): #load data
        objFile = open(objFileName, "r")
        for line in objFile:
            strData = line.split(",")  # readline() reads a line of the data into 2 elements
            dicRow = {"Task": strData[0].strip(), "Priority": strData[1].strip()}
            lstTable.append(dicRow)
        objFile.close()
    # end of function

    @staticmethod
    def AddTask (Task, Priority, TableofData):
        dicRow = {"Task": strTask, "Priority": strPriority}
        lstTable.append(dicRow)
    #end of function

    @staticmethod
    def RemoveTask (KeyToRemove, TableofData):
        blnItemRemoved = False  # Creating a boolean Flag
        intRowNumber = 0
        while (intRowNumber < len(lstTable)):
            if (strKeyToRemove ==
                    str(list(dict(lstTable[intRowNumber]).values())[0])):  # the values function creates a list!
                del lstTable[intRowNumber]
                blnItemRemoved = True
            # end if
            intRowNumber += 1
        # end for loop
        return blnItemRemoved
    #end of function

    @staticmethod
    def SaveData (FileName, TableofData): #Option 4
        objFile = open(objFileName, "w")
        for dicRow in lstTable:
            objFile.write(dicRow["Task"] + "," + dicRow["Priority"] + "\n")
        objFile.close()
    #end of function
#end data processing



# Step 1
# When the program starts, load the any data you have
# in a text file called ToDo.txt into a python Dictionary.
DataProcessing.LoadData(objFileName, lstTable)

# Step 2
# Display a menu of choices to the user
while(True):
    output.MenuOptions() #print out menu options

    strChoice = UserInput.MenuOptionInput() #user input for option number

    # Step 3
    # Show the current items in the table
    if (strChoice.strip() == '1'):
        output.CurrentTasksOutput(lstTable)


    # Step 4
    # Add a new item to the list/Table
    elif(strChoice.strip() == '2'):
        strTask, strPriority = UserInput.AddTaskInput() #add task and priority
        DataProcessing.AddTask(strTask, strPriority, lstTable)
        output.CurrentTasksOutput(lstTable) #to show the table
        continue

    # Step 5
    # Remove a new item to the list/Table
    elif(strChoice == '3'):
        #5a-Allow user to indicate which row to delete
        strKeyToRemove = UserInput.RemoveTaskInput()
        blnItemRemoved = DataProcessing.RemoveTask(strKeyToRemove, lstTable)
        output.RemoveTaskOutput(blnItemRemoved) #remove the row
        output.CurrentTasksOutput(lstTable) #show current table
        continue

    # Step 6
    # Save tasks to the ToDo.txt file
    elif(strChoice == '4'):
        #5a Show the current items in the table
        output.CurrentTasksOutput(lstTable)
        if ("y" == UserInput.SaveDataInput()):
            DataProcessing.SaveData(objFileName, lstTable)
            output.DataSaved()
        #5b Ask if they want save that data
        else:
            output.DataNotSaved()
        continue #to show the menu

    elif (strChoice == '5'):
        break #and Exit the program

