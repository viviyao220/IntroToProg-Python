#-------------------------------------------------#
# Title: Working with Dictionaries
# Dev:   Yao Lu
# Date:  Feb 8th, 2018
#-------------------------------------------------#

# -- Data --#
# declare variables and constants
# objFile = An object that represents a file
# strData = A row of text data from the file
# dicRow = A row of data separated into elements of a dictionary {Task,Priority}
# lstTable = A dictionary that acts as a 'table' of rows
# strMenu = A menu of user options
# strChoice = Capture the user option selection

# -- Input/Output --#
# User can see a Menu (Step 2)
# User can see data (Step 3)
# User can insert or delete data(Step 4 and 5)
# User can save to file (Step 6)

# -- Processing --#
# Step 1
# When the program starts, load the any data you have
# in a text file called ToDo.txt into a python Dictionary.

# Step 2
# Display a menu of choices to the user

# Step 3
# Display all todo items to user

# Step 4
# Add a new item to the list/Table

# Step 5
# Remove a new item to the list/Table

# Step 6
# Save tasks to the ToDo.txt file

# Step 7
# Exit program
# -------------------------------

objFileName = open("C:\\_PythonClass\\ToDo.txt")
strData = ""
dicRow = {}
lstTable = []

# Step 1 - Load data from a file
# When the program starts, load each "row" of data
# in "ToDo.txt" into a python Dictionary.
# Add the each dictionary "row" to a python list "table"
objFile = open("C:\\_PythonClass\\ToDo.txt", "r")
for row in objFile:
    strData = row.split(",")
    dicRow = {"Tasks": strData[0], "Priority": strData[1].strip("\n")}
    lstTable.append(dicRow)
objFile.close()

# Step 2 - Display a menu of choices to the user
while (True):
    print("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 5] - "))
    print()  # adding a new line

    # Step 3 -Show the current items in the table
    if (strChoice.strip() == '1'):
        print("The following tasks were saved: ")
        for line in lstTable:
            print(line["Tasks"] + ": " + line["Priority"])

    # Step 4 - Add a new item to the list/Table
    elif (strChoice.strip() == '2'):
        strTask = str(input("What's the next task you would like to add? "))
        strPriority = str(input("What's the priority of this task? (low, medium, high) "))
        dicRow = {"Tasks": strTask, "Priority": strPriority}
        lstTable.append(dicRow)
        print(lstTable)
        continue

    # Step 5 - Remove a new item to the list/Table
    elif (strChoice == '3'):
        intRow = 0
        strRemove = str(input("Which task do you want to remove? "))
        blnRemove = False
        while (intRow < len(lstTable)):
            dicRemoveLine = lstTable[intRow]
            if (strRemove == (dicRemoveLine["Tasks"])):
                del lstTable[intRow]
                print("The task " + strRemove + " is removed. Current to-do list is: ")
                print(lstTable)
                blnRemove = True
                break
            intRow += 1
        if (blnRemove == False):
            print("Sorry, the task was not found")


    # Step 6 - Save tasks to the ToDo.txt file
    elif (strChoice == '4'):
        print("The current to-do list is ")
        for line in lstTable:
            print(line["Tasks"] + ": " + line["Priority"])
        if (str(input("Would you like to save the list to the txt file? (y/n) ")).lower() == "y"):
            objFile = open("C:\\_PythonClass\\ToDo.txt", "w")
            for list in lstTable:
                objFile.write(list["Tasks"] + "," + list["Priority"] + "\n")
                objFile.close()
            print("The todo list is saved to the file. Please press Enter Key to continue")
        else:
            print("The todo list was not saved to the file. Pleae press Enter Key to continye")
            continue
    elif (strChoice == '5'):
        break  # and Exit the program


